package com.example.zeeshan.reportcard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ReportCard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_card);
    }
    public void submit (View view){

        EditText maths = (EditText)findViewById(R.id.maths);
        EditText name = (EditText)findViewById(R.id.name);
        EditText phy = (EditText)findViewById(R.id.physics);
        EditText chem = (EditText)findViewById(R.id.chem);
        EditText isl = (EditText)findViewById(R.id.islamiat);
        EditText urdu = (EditText)findViewById(R.id.urdu);
        EditText eng = (EditText)findViewById(R.id.english);

        Intent intent = new Intent(this,Grade.class);

        float total = 600;
        float divide =100;

        int maths1 = Integer.parseInt(maths.getText().toString());
        int phy1 = Integer.parseInt(phy.getText().toString());
        int chem1 = Integer.parseInt(chem.getText().toString());
        int isl1 = Integer.parseInt(isl.getText().toString());
        int urdu1 = Integer.parseInt(urdu.getText().toString());
        int eng1 = Integer.parseInt(eng.getText().toString());

        float result = ((maths1 + phy1 + chem1 + isl1 + urdu1 + eng1)/total)*divide ;

        intent.putExtra("name1",name.getText().toString());
        intent.putExtra("maths1",maths1);
        intent.putExtra("phy1",phy1);
        intent.putExtra("chem1",chem1);
        intent.putExtra("isl1",isl1);
        intent.putExtra("urdu1",urdu1);
        intent.putExtra("eng1",eng1);
        intent.putExtra("result",result);
        startActivity(intent);
    }
}
