package com.example.zeeshan.reportcard;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Grade extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);


        TextView txt1 = (TextView) findViewById(R.id.name);
        TextView txt2 = (TextView)findViewById(R.id.maths);
        TextView txt3 = (TextView)findViewById(R.id.phy);
        TextView txt4 = (TextView)findViewById(R.id.chem);
        TextView txt5 = (TextView)findViewById(R.id.urdu);
        TextView txt6 = (TextView)findViewById(R.id.isl);
        TextView txt7 = (TextView)findViewById(R.id.eng);
        TextView txt8 = (TextView)findViewById(R.id.result);
          TextView txt9 = (TextView)findViewById(R.id.grade);


        Intent intent = getIntent();

        String str1 = ("Your Name : " + intent.getStringExtra("name1"));
        int maths = intent.getIntExtra("maths1",0);
        int phy = intent.getIntExtra("phy1",0);
        int chem = intent.getIntExtra("chem1",0);
        int isl = intent.getIntExtra("isl1",0);
        int urdu = intent.getIntExtra("urdu1",0);
        int eng = intent.getIntExtra("eng1",0);
        float result = intent.getFloatExtra("result",0);

        if(result >= 85 && result <= 100 ){
            txt9.setText(" Your Grade: A+ ");
        }
        else if (result >= 80 && result <= 84.9){
            txt9.setText(" Your Grade: A- ");
        }
        else if (result >= 70 && result <= 79.9){
            txt9.setText(" Your Grade: B ");
        }
        else if (result >= 60 && result <= 69.9){
            txt9.setText(" Your Grade: C ");
        }
        else if (result >= 50 && result <= 59.9){
            txt9.setText(" Your Grade: D ");
        }
        else if (result < 50){
            txt9.setText(" Sorry You Fail ");
        }

        String math1 = String.valueOf("Marks 1: " +maths);
        String phy1 = String.valueOf("Marks 2: " +phy);
        String chem1 = String.valueOf("Marks 3: " +chem);
        String isl1 = String.valueOf("Marks 5: " +isl);
        String urdu1 = String.valueOf("Marks 4: " +urdu);
        String eng1 = String.valueOf("Marks 6: " +eng);
        String result1 = String.valueOf("Your Percentage: " + result);


        txt1.setText(str1);
        txt2.setText(math1);
        txt3.setText(phy1);
        txt4.setText(chem1);
        txt5.setText(isl1);
        txt6.setText(urdu1);
        txt7.setText(eng1);
        txt8.setText(result1);

    }
    }

