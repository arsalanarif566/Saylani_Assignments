package com.example.muhammad.notebook;


import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class DeleteFragment extends Fragment {

    EditText id;
    Button del;
    DatabaseHelper databaseHelper;
    ListView listView;
    ArrayList<String> list ;
    Cursor cursor;
    String et_id,title, desc;

    public DeleteFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_delete, container, false);
        databaseHelper = new DatabaseHelper(getContext());

        del = (Button)v.findViewById(R.id.delete);
        id = (EditText)v.findViewById(R.id.del_id);
        listView = (ListView)v.findViewById(R.id.et_listView);
        list = new ArrayList<>();

        cursor = databaseHelper.getData();

        while (cursor.moveToNext()){

            et_id = cursor.getString(0);
            title = cursor.getString(1);
            desc = cursor.getString(2);

            list.add("(ID): " + et_id + " (TITLE): " + title + "  (DESCRIPTION): " + desc);

            ListAdapter listAdapter = new ArrayAdapter<>(getContext(),R.layout.display,list);
            listView.setAdapter(listAdapter);
        }


        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                databaseHelper.deleteData(id.getText().toString());
                Toast.makeText(getContext(),"Data Deleted", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }

}
