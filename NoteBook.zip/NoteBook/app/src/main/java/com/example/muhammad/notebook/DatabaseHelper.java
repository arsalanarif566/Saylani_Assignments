package com.example.muhammad.notebook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by MUHAMMAD on 4/11/2017.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static String DATABASE_NAME = "notebook.db";
    private static String TABLE_NAME = "notebook";
    String title;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, TITLE TEXT, DESCRIPTION TEXT, TIME TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS" +TABLE_NAME);
        onCreate(db);
    }

    public boolean Data(String title ,String desc){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put("TITLE",title);
        contentValues.put("DESCRIPTION",desc);

        long result = db.insert(TABLE_NAME,null,contentValues);

        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getData (){

        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME ;
        Cursor cursor = db.rawQuery(query,null);
        return cursor;
    }

    public void deleteData (String id){
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME," ID = '"+id+"'", null);
    }

    public void updateData (String update_id, String update_title, String update_desc){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("TITLE",update_title );
        cv.put("DESCRIPTION",update_desc);

        db.update(TABLE_NAME,cv,"ID = '"+update_id+"'", null);

    }
}
