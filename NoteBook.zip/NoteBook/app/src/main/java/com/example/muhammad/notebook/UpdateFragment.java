package com.example.muhammad.notebook;


import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateFragment extends Fragment {

    EditText update_id , update_title,update_desc;
    ListView update_listView;
    Button update;
    String id,title, desc;
    ArrayList<String> list ;
    Cursor cursor;
    DatabaseHelper databaseHelper;

    public UpdateFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_update, container, false);

        update_id = (EditText)v.findViewById(R.id.update_id);
        update_title = (EditText)v.findViewById(R.id.update_title);
        update_desc = (EditText)v.findViewById(R.id.update_desc);
        update = (Button)v.findViewById(R.id.et_update);
        update_listView = (ListView)v.findViewById(R.id.update_listView);

        list = new ArrayList<>();
        databaseHelper = new DatabaseHelper(getContext());

        cursor = databaseHelper.getData();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.updateData(update_id.getText().toString(), update_title.getText().toString(), update_desc.getText().toString());
                Toast.makeText(getContext(), "Data Updated", Toast.LENGTH_SHORT).show();
                update_id.setText("");
                update_title.setText("");
                update_desc.setText("");
            }
        });


        while (cursor.moveToNext()){

            id = cursor.getString(0);
            title = cursor.getString(1);
            desc = cursor.getString(2);

            list.add("(ID): " + id + " (TITLE): " + title + "  (DESCRIPTION): " + desc);

            ListAdapter listAdapter = new ArrayAdapter<>(getContext(),R.layout.display,list);
            update_listView.setAdapter(listAdapter);
        }
        return v;
    }

}
