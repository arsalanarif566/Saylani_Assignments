package com.example.muhammad.notebook;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddFragment extends Fragment {

    EditText title,desc;
    Button add;
    DatabaseHelper databaseHelper;

    public AddFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_add, container, false);

        databaseHelper = new DatabaseHelper(getContext());

        title = (EditText)v.findViewById(R.id.et_title);
        desc = (EditText)v.findViewById(R.id.et_desc);
        add = (Button)v.findViewById(R.id.et_add);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean result = databaseHelper.Data(title.getText().toString(),desc.getText().toString());
                if(result) {
                    title.setText("");
                    desc.setText("");

                    Toast.makeText(getContext(), "Data Inserted", Toast.LENGTH_SHORT).show();

                }
                else
                    Toast.makeText(getContext(),"Data Not Inserted",Toast.LENGTH_SHORT).show();
            }
        });
        return v;
    }

    }

