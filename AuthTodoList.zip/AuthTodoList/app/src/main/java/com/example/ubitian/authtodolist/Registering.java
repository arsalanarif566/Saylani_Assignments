package com.example.ubitian.authtodolist;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registering extends AppCompatActivity implements View.OnClickListener {

    
    EditText username , password ;
    Button etregister;
    TextView signin;
    DatabaseReference database;
    private ProgressDialog progressDialog;
    FirebaseAuth mAuth;
    String User , Pass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registering);

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference();
        progressDialog = new ProgressDialog(this);


        username = (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.pass);
        etregister = (Button)findViewById(R.id.register1);
        signin = (TextView)findViewById(R.id.signin);

        etregister.setOnClickListener(this);
        signin.setOnClickListener(this);
        
    }

    private void registerUser() {
         User = username.getText().toString();
         Pass = password.getText().toString();

        if(TextUtils.isEmpty(User) || TextUtils.isEmpty(Pass)){
            Toast.makeText(this, "Fill Email and Password for Sign In..", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.setMessage("Registering...");
        progressDialog.show();

        username.setText("");
        password.setText("");

        mAuth.createUserWithEmailAndPassword(User, Pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            progressDialog.dismiss();
                            finish();
                            Toast.makeText(Registering.this, "Registering...", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        }

                        if (!task.isSuccessful()) {
                            Toast.makeText(Registering.this, "CouldNot Register...", Toast.LENGTH_SHORT).show();
                            return;
                        }

                    }
                });
    }

    @Override
    public void onClick(View view) {
        if(view == signin){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if(view == etregister){
            registerUser();
        }
    }

    }



