package com.example.ubitian.authtodolist;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

/**
 * Created by Ubitian on 2/6/2017.
 */

public class dataAdapter extends ArrayAdapter<Data> {

    DatabaseReference database;
    Data mydata;
    FirebaseAuth mAuth;
    String uid;

     public dataAdapter(Context context, ArrayList<Data> list) {
        super(context, R.layout.display , list );
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if(v == null){
            v = LayoutInflater.from(getContext()).inflate(R.layout.display, parent, false);

        }

        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        mydata = getItem(position);
        uid = mAuth.getCurrentUser().getUid();

        TextView mname = (TextView)v.findViewById(R.id.name);
        mname.setText("Name : " + mydata.getName());
        TextView mage = (TextView)v.findViewById(R.id.age);
        mage.setText("Age : " + String.valueOf(mydata.getAge()));
        TextView mid = (TextView)v.findViewById(R.id.id);
        mid.setText("ID : " + mydata.getId());
        CheckBox check = (CheckBox)v.findViewById(R.id.check);
        check.setChecked(mydata.isCheck());

        check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                Data pos = getItem(position);
                String val = pos.getId();
                database.child("Student").child(uid).child(val).child("check").setValue(isChecked);

            }
        });

        return v;
    }
}
