package com.example.zeeshan.basketball;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Basketball extends AppCompatActivity {

    int score_A = 0;
    int score_B = 0;
    TextView b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basketball);
    }

    //---------------------------
    public void Button_1A(View view){
        TextView textView = (TextView) findViewById(R.id.scoreA);
        score_A =score_A + 3;

        textView.setText(Integer.toString(score_A));

    }
    //-------------------------


    public void Button_2A(View view){
        TextView textView = (TextView) findViewById(R.id.scoreA);
        score_A =score_A + 2;

        textView.setText(Integer.toString(score_A));

    }

    //------------------------

    public void Button_3A(View view){
        TextView textView = (TextView) findViewById(R.id.scoreA);
        score_A =score_A + 1;

        textView.setText(Integer.toString(score_A));

    }

    //------------------------

    public void Button_1B(View view){
        TextView textView = (TextView) findViewById(R.id.scoreB);
        score_B =score_B + 3;
        textView.setText(Integer.toString(score_B));

        }

    //----------------------

    public void Button_2B(View view){
        TextView textView = (TextView) findViewById(R.id.scoreB);
        score_B =score_B + 2;
        textView.setText(Integer.toString(score_B));

        }

    //---------------------

    public void Button_3B(View view){
        TextView textView = (TextView) findViewById(R.id.scoreB);
        score_B =score_B + 1;
        textView.setText(Integer.toString(score_B));


    }
    //-------------------------
    public void Reset (View view){
         score_A = 0;
         score_B = 0;

         minus(score_A);
         minus(score_B);
        }

    private  void minus (int score){
        TextView textView = (TextView) findViewById(R.id.scoreA);
        textView.setText(Integer.toString(score));
        TextView text = (TextView) findViewById(R.id.scoreB);
        text.setText(Integer.toString(score));

    }
}
